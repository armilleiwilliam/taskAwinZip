<?php

namespace MerchantTransactionsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MerchantTransactionsBundle extends Bundle
{
}
