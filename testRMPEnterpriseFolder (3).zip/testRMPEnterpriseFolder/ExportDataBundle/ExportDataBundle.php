<?php

namespace ExportDataBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ExportDataBundle extends Bundle
{
}
